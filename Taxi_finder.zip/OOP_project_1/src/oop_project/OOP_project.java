/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package oop_project;

import java.awt.HeadlessException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;
import static oop_project.Driver.driver_index;



            

            
////////////////////////////////////////////////////////////////////////////////////////////
            
            
   
/**
 *
 * @author LENOVO
 */
public class OOP_project {
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        new Loginpage().setVisible(true);
            
                    // TODO code application logic here
        }
    
}
